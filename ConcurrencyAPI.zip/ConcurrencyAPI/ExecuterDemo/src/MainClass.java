import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import com.threadwork.RunnableTask;
public class MainClass {
	public static void main(String[] args) {
		method1();
	}
	public static void method1(){
		
		ExecutorService service = Executors.newSingleThreadExecutor();
		for(int i=1;i<=5;i++)service.execute(new RunnableTask());
	}
	
	public static void method2(){
		ExecutorService service = Executors.newCachedThreadPool();
		for(int i=1;i<=5;i++)service.execute(new RunnableTask());
	}

	public static void method3(){
		ExecutorService service = Executors.newFixedThreadPool(2);
		for(int i=1;i<=3;i++)service.execute(new RunnableTask());
	}

	public static void method4(){
		ExecutorService service = Executors.newScheduledThreadPool(2);
		for(int i=1;i<=5;i++)service.execute(new RunnableTask());
	}	

	public static void method5(){
		BlockingQueue<Runnable> workQueue= new ArrayBlockingQueue<>(10);
		ThreadPoolExecutor executors = 
				new ThreadPoolExecutor(2, 5, 1, TimeUnit.MINUTES, workQueue);
		
		executors.setRejectedExecutionHandler(new RejectionHandler());	
		for (int i =0;i<=15;i++){
			executors.execute(new RunnableTask());
		}
	}
	private static class RejectionHandler implements RejectedExecutionHandler{
		@Override
		public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
			System.out.println("Regected task added");
			executor.execute(r);
		}
	}
}
