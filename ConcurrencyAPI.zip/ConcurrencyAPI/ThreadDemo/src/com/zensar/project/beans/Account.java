package com.zensar.project.beans;
public class Account {

	private static int SUCCESS , FAIL =0;
	private int balance;
	public Account() {}
	public Account(int balance) {
		super();
		this.balance = balance;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public synchronized int deposit(int amount) {		
		balance=balance+amount;
		return balance;
	}
	public synchronized int withdraw(int amount){	
		balance=balance-amount;
		SUCCESS++;
		System.out.println("\n\t\tWithdraw Success	"+	SUCCESS);
		return balance;
	}
}