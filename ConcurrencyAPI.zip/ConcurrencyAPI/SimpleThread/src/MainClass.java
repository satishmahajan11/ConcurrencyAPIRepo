
public class MainClass {
	public static void main(String[] args) throws InterruptedException {
		MyResource rs = new MyResource();
		Thread t1 = new Thread(rs, "th1");
		Thread t2= new Thread(rs,"th2");	
		t2.start();
		t2.join();
		t1.setPriority(7);
		t1.start();
	}
}
