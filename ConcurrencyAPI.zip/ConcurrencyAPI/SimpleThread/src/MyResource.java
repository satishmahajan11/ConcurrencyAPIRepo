
public class MyResource  implements Runnable{
	@Override
	public void run() {

		Thread t = Thread.currentThread();
		if(t.getName().equals("th1")){
			for(int i=1;i<=5;i++){
				try {
					Thread.sleep(1000);
					System.out.println( t.getName()+ "	Tick	"+i);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		else if(t.getName().equals("th2")){
			for(int i=1;i<=5;i++){
				try {
					Thread.sleep(200);
					System.out.println( t.getName()+ "	Tick	"+i);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}	
			}
		}
	}

}
