package com.threadwork;

public class RunnableTask implements Runnable {
	private static int COUNTER=0;
	@Override
	public void run() {
		try {
			for (int i=1;i<=10;i++){
				System.out.println("Tic "+i);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
