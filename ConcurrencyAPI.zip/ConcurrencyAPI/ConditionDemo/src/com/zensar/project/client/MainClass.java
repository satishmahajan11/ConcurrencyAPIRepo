package com.zensar.project.client;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;

import com.zensar.project.threadwork.Customer;
public class MainClass {
	public static void main(String[] args) {
		Thread th1 = new Thread(new Customer("rahul"),"rahul");
		Thread th2= new Thread(new Customer("anil"),"anil");
		Thread th3 = new Thread(new Customer("satish") , "satish");
		th1.start();
		th2.start();
		th3.start();
	
	}
}
