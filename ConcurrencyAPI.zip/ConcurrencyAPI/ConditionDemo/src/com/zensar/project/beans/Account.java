package com.zensar.project.beans;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
public class Account {
	private Lock lock ;
	private Condition notEnoughMoneyCondition;
	private static int SUCCESS , FAIL =0;
	private int balance;
	public Account() {}
	public Account(int balance) {
		super();
		this.balance = balance;
		lock= new ReentrantLock();
		notEnoughMoneyCondition=lock.newCondition();
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int deposit(int amount) throws InterruptedException{
		lock.lock();
		try {
			balance=balance+amount;
			notEnoughMoneyCondition.signalAll();
			return balance;
		} finally{
			lock.unlock();
		}
	}
	 public int withdraw(int amount) throws InterruptedException {
		 lock.lock();
		try {
			if(balance<0||(getBalance()-amount)<0){
				FAIL++;
				System.out.println("\n\t\tWithdraw Fail	"+ FAIL);
				notEnoughMoneyCondition.await();
				return balance;
			}
			else{
				balance=balance-amount;
				SUCCESS++;
				System.out.println("\n\t\tWithdraw Success	"+	SUCCESS);
				return balance;
			}
		} 
		finally{
			lock.unlock();
		}
		
	}
}
