import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.ls.LSInput;
public class Resource {
	static List<String> list =Collections.synchronizedList(new ArrayList<String>());
	static Map<String, String>map = Collections.synchronizedMap(new HashMap<String, String>());
	public synchronized void addElement(String element){
			list.add(element);
	}
	public synchronized boolean removeElement(String element){
		if(list.contains(element)){
			list.remove(list.indexOf(element));
			return true;
		}
		return false;
	}
	
	public int getSize(){
		return list.size();
	}
}
