import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
public class MainClass {
	public static void main(String[] args) {
		Map<String, String>lsit = Collections.synchronizedMap(new HashMap<String, String>());
	}
}
