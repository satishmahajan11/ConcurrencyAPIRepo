package com.zensar.collectionwork;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class ConcurrentCollectionClassesWork {
		public static void copyOnArrayList(){
			HashMap<String, String>list = new HashMap<>();
			list.put("", "");
		}
}
