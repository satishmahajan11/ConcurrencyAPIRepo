import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class RunnableTarget implements Runnable {

	static Resource resource;
	
	static{
		resource=new Resource();
	}
	@Override
	public void run() {
			
	}
		
}
