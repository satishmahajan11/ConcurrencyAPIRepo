import java.util.HashMap;
import java.util.concurrent.ForkJoinPool;
public class MainClass {
	public static void main(String[] args) {
		method2();
	}

	public static void method1(){
		int poolSize = Runtime.getRuntime().availableProcessors();
	    ForkJoinPool pool = new ForkJoinPool(poolSize);   
	    pool.invoke(new MyRecursiveAction(10));  
	}
	
	public static void method2(){
		 int poolSize = Runtime.getRuntime().availableProcessors();
		   ForkJoinPool pool = new ForkJoinPool(poolSize);   
		  System.out.println( pool.invoke(new MyRecursiveTask(4)));  
	}
}