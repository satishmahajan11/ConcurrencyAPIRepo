public class MainClass {
	public static void main(String[] args) {
		new Thread(new RunnableTarget()).start();
	}

}
