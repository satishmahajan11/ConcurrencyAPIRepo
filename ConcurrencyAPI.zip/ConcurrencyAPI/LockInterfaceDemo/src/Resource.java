public class Resource {
    public void doSomething(){
        System.out.println("doSomething() call");
    }
    public void doLogging(){
       System.out.println("doLogging() call");
    }
}