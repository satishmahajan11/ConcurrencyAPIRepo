import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class RunnableTarget implements Runnable{
	private Resource resource;
	private Lock lock;
	public RunnableTarget() {
		resource= new Resource();
		lock= new ReentrantLock();
	}
	@Override
	public void run() {

		lock.lock();
		try {
			if(lock.tryLock(10, TimeUnit.SECONDS)){
				resource.doSomething();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}finally{
			lock.unlock();
		}
		resource.doLogging();
	}



}
